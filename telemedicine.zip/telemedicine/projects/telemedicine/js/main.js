// RuralCare - Telemedicine Access for Rural Healthcare
// Developed by Uravashee Kumari | GITS Udaipur | ICMART-2026

// Initialize demo data on first load
window.onload = function() {
  // Add demo patient if none exist
  const patients = JSON.parse(localStorage.getItem('patients') || '[]');
  if (patients.length === 0) {
    const demoPatient = {
      id: 1001,
      name: "Ramesh Meena",
      email: "demo@patient.com",
      mobile: "9876543210",
      age: 35,
      location: "Jhadol Village, Udaipur",
      password: "1234",
      appointments: [],
      records: []
    };
    localStorage.setItem('patients', JSON.stringify([demoPatient]));
  }

  // Add demo appointments if none exist
  const appointments = JSON.parse(localStorage.getItem('appointments') || '[]');
  if (appointments.length === 0) {
    const demoAppts = [
      {
        id: 2001,
        patientId: 1001,
        patientName: "Ramesh Meena",
        doctorId: 1,
        doctorName: "Dr. Ramesh Sharma",
        specialization: "General Physician",
        date: "2026-05-20",
        time: "10:00 AM",
        reason: "Fever and cold",
        status: "confirmed"
      }
    ];
    localStorage.setItem('appointments', JSON.stringify(demoAppts));
  }

  // Add demo records if none exist
  const records = JSON.parse(localStorage.getItem('records') || '[]');
  if (records.length === 0) {
    const demoRecords = [
      {
        patientId: 1001,
        date: "2026-05-10",
        doctorName: "Dr. Ramesh Sharma",
        diagnosis: "Viral Fever",
        prescription: "Paracetamol 500mg twice daily, rest for 3 days"
      }
    ];
    localStorage.setItem('records', JSON.stringify(demoRecords));
  }
};
